//
//  AppDelegate.h
//  Calculator
//
//  Created by Jenna Tsedensodnom on 2/1/15.
//  Copyright (c) 2015 Jenna Tsedensodnom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

